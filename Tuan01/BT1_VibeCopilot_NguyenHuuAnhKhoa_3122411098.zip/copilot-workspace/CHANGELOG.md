# Changelog 👉 GitHub Copilot Vibe Coding Workshop

<a name="0.1.0"></a>
## 0.1.0 (2025-05-30)

### Features

- Initial code commit

<!-- *Features*
* ...

*Bug Fixes*
* ...

*Breaking Changes*
* ... -->
