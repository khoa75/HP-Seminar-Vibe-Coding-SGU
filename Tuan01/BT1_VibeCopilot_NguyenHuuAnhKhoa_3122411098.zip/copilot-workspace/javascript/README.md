# Getting Started with JavaScript

Here's the starting point for your JavaScript app development.

If you want to see the complete example, check out this directory, [/complete/javascript](../complete/javascript/).
