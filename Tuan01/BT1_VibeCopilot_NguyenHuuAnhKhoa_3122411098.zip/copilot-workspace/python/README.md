# Getting Started with Python

Here's the starting point for your Python app development.

If you want to see the complete example, check out this directory, [/complete/python](../complete/python/).
