package com.contoso.socialapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialappApplicationTests {

	@Test
	void contextLoads() {
	}

}
