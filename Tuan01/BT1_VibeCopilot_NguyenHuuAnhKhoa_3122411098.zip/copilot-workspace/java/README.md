# Getting Started with Java

Here's the starting point for your Java app development.

If you want to see the complete example, check out this directory, [/complete/java](../complete/java/).
