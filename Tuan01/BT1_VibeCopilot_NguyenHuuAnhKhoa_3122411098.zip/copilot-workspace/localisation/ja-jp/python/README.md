# Python を始める

こちらはPythonアプリ開発の出発点です。

完全な例を見たい場合は、このディレクトリを確認してください。[/complete/python](../complete/python/)

---

**免責事項**: この文書は[GitHub Copilot](https://docs.github.com/copilot/about-github-copilot/what-is-github-copilot)によってローカライズされています。そのため、間違いを含む可能性があります。不適切または間違った翻訳を見つけた場合は、[issue](https://github.com/microsoft/github-copilot-vibe-coding-workshop/issues/new)を作成してください。
