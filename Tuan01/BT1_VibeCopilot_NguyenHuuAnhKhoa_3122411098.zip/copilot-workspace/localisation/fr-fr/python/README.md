# Démarrer avec Python

Voici le point de départ pour le développement de votre application Python.

Si vous voulez voir l'exemple complet, consultez ce répertoire, [/complete/python](../complete/python/).

---

**Avertissement**: Ce document a été localisé par [GitHub Copilot](https://docs.github.com/copilot/about-github-copilot/what-is-github-copilot). Par conséquent, il peut contenir des erreurs. Si vous trouvez une traduction inappropriée ou erronée, veuillez créer un [issue](https://github.com/microsoft/github-copilot-vibe-coding-workshop/issues/new).
