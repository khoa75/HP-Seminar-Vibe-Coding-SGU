# Comenzando con Python

Aquí está el punto de partida para el desarrollo de tu aplicación Python.

Si quieres ver el ejemplo completo, consulta este directorio, [/complete/python](../complete/python/).

---

**Disclaimer**: Este documento ha sido localizado por [GitHub Copilot](https://docs.github.com/copilot/about-github-copilot/what-is-github-copilot). Por lo tanto, puede contener errores. Si encuentras alguna traducción que sea inapropiada o errónea, por favor crea un [issue](https://github.com/microsoft/github-copilot-vibe-coding-workshop/issues/new).
