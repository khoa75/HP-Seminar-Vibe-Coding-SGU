# .NET 入门

这是您 .NET 应用开发的起点。

如果您想查看完整示例，请查看此目录：[/complete/dotnet](../complete/dotnet/)。

---

**免责声明**: 本文档由 [GitHub Copilot](https://docs.github.com/copilot/about-github-copilot/what-is-github-copilot) 本地化。因此，可能包含错误。如果您发现任何不当或错误的翻译，请创建一个 [issue](https://github.com/microsoft/github-copilot-vibe-coding-workshop/issues/new)。
