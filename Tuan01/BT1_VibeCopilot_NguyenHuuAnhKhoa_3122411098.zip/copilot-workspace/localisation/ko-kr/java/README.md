# Java 시작하기

Java 앱 개발을 위한 시작점입니다.

완성된 예제를 보고 싶다면, 이 디렉터리를 확인하세요: [/complete/java](../complete/java/).

---

**면책조항**: 이 문서는 [GitHub Copilot](https://docs.github.com/copilot/about-github-copilot/what-is-github-copilot)에 의해 현지화되었습니다. 따라서 실수가 포함될 수 있습니다. 부적절하거나 잘못된 번역을 발견하면 [issue](https://github.com/microsoft/github-copilot-vibe-coding-workshop/issues/new)를 생성해 주세요.
