# Começando com JavaScript

Aqui está o ponto de partida para o desenvolvimento da sua aplicação JavaScript.

Se você quiser ver o exemplo completo, confira este diretório, [/complete/javascript](../complete/javascript/).

---

**Aviso**: Este documento foi localizado pelo [GitHub Copilot](https://docs.github.com/copilot/about-github-copilot/what-is-github-copilot). Portanto, pode conter erros. Se você encontrar alguma tradução inadequada ou incorreta, por favor crie um [issue](https://github.com/microsoft/github-copilot-vibe-coding-workshop/issues/new).
